package com.example.touchassist

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private typealias Step = (() -> Unit) -> Unit

class AssistService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistService? = null

        /** الإيماءة اللي لسه متسجلة ومستنية الاسم في شاشة الحفظ */
        @Volatile
        var pending: Gesture? = null
    }

    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val handler = Handler(Looper.getMainLooper())
    private val fadeHandler = Handler(Looper.getMainLooper())

    private var button: AssistButton? = null
    private var buttonLp: WindowManager.LayoutParams? = null
    private var menu: View? = null
    private var recorder: View? = null
    private var placer: View? = null
    private val pageStack = ArrayList<String>()

    private var playing = false
    private var runToken = 0
    private var dragStartX = 0
    private var dragStartY = 0

    // الدواير الثابتة (Armed)
    private var armedGesture: Gesture? = null
    private var armedView: View? = null
    private var armedLp: WindowManager.LayoutParams? = null
    private var armedBaseX = 0
    private var armedBaseY = 0
    private var armedMulti = false
    private var armedInteractive = false
    private var armedTx = 0f
    private var armedTy = 0f
    private var onEnd: (() -> Unit)? = null

    private class MI(val icon: String, val label: String, val action: String)
    private class Spec(val start: Long, val dur: Long, val path: Path)
    private class Chunk(val specs: List<Spec>, val minStart: Long, val endTime: Long)
    private class Seg(val path: Path, val dur: Long)

    // ───────────── دورة حياة الخدمة ─────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refreshButton()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeOverlays()
        handler.post { clampButton() }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        instance = null
        super.onDestroy()
    }

    private fun cleanup() {
        stopPlaying()
        closeOverlays()
        removeButton()
    }

    // ───────────── أدوات مساعدة ─────────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun rounded(color: String, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(Color.parseColor(color))
        d.cornerRadius = dp(radiusDp).toFloat()
        return d
    }

    private fun fullScreenParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    // ───────────── الزر العائم ─────────────

    fun refreshButton() {
        removeButton()
        if (Store.buttonEnabled(this)) {
            addButton()
            applyButtonSettings()
        }
    }

    /**
     * إعدادات الأيقونة: العادية من الإعدادات، ولو فيه كورة ثابتة ظاهرة بتتطبّق إعدادات الكورة نفسها
     * (مدة الضغط المطوّل ومهلة الضغطتين وأهدافها) من غير ما تتأثر بإعدادات الهاتف.
     */
    private fun applyButtonSettings() {
        val v = button ?: return
        val g = armedGesture
        val b = g?.ballActions
        fun has(k: String) = b != null && (b[k] ?: "none") != "none"
        v.hasDouble = Store.getAction(this, "double") != "none" || has("main")
        v.hasTriple = Store.getAction(this, "triple") != "none"
        v.hasQuad = Store.getAction(this, "quad") != "none"
        v.hasFlick = listOf("up", "down", "left", "right").any { Store.getAction(this, "flick_$it") != "none" }
        v.longPressMs = (g?.ballLongMs ?: Store.longPressMs(this)).toLong()
        v.doubleTapMs = (g?.ballDoubleMs ?: Store.doubleTapMs(this)).toLong()
    }

    /** الزر يرجع واضح 100% ولما تسيبه ~4 ثواني يبهت لشفافية "Idle Opacity" زي iOS. */
    private fun wakeButton() {
        fadeHandler.removeCallbacksAndMessages(null)
        button?.animate()?.cancel()
        button?.alpha = 1f
        fadeHandler.postDelayed({
            button?.animate()?.alpha(Store.idleOpacity(this) / 100f)?.setDuration(400)?.start()
        }, 4000)
    }

    private fun addButton() {
        val size = dp(Store.btnSize(this))
        val v = AssistButton(this)
        v.hasDouble = Store.getAction(this, "double") != "none"
        v.hasTriple = Store.getAction(this, "triple") != "none"
        v.hasQuad = Store.getAction(this, "quad") != "none"
        v.hasFlick = listOf("up", "down", "left", "right").any { Store.getAction(this, "flick_$it") != "none" }
        v.longPressMs = Store.longPressMs(this).toLong()
        v.doubleTapMs = Store.doubleTapMs(this).toLong()

        val lp = WindowManager.LayoutParams(
            size, size,
            if (Settings.canDrawOverlays(this)) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val (sw, sh) = screenSize()
        val px = Store.posX(this)
        val py = Store.posY(this)
        lp.x = (if (px < 0) (sw - size) / 2 else px).coerceIn(0, max(0, sw - size))
        lp.y = (if (py < 0) sh - size - dp(6) else py).coerceIn(0, max(0, sh - size))

        v.listener = object : AssistButton.Listener {
            override fun onSingle() = trigger("single")
            override fun onDouble() = trigger("double")
            override fun onLong() = trigger("long")
            override fun onTriple() = trigger("triple")
            override fun onQuad() = trigger("quad")
            override fun onFlick(dir: String) = trigger("flick_$dir")
            override fun onPress() {
                dragStartX = lp.x
                dragStartY = lp.y
                wakeButton()
            }

            override fun onDrag(dx: Float, dy: Float) {
                val (w, h) = screenSize()
                lp.x = (dragStartX + dx).toInt().coerceIn(0, max(0, w - lp.width))
                lp.y = (dragStartY + dy).toInt().coerceIn(0, max(0, h - lp.height))
                try {
                    wm.updateViewLayout(v, lp)
                } catch (_: Exception) {
                }
            }

            override fun onDragEnd() {
                val (w, hh) = screenSize()
                snapToEdge(lp, w, hh)
                try {
                    wm.updateViewLayout(v, lp)
                } catch (_: Exception) {
                }
                Store.setPos(this@AssistService, lp.x, lp.y)
                wakeButton()
            }
        }
        try {
            wm.addView(v, lp)
            button = v
            buttonLp = lp
            wakeButton()
        } catch (_: Exception) {
            try {
                lp.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                wm.addView(v, lp)
                button = v
                buttonLp = lp
                wakeButton()
            } catch (_: Exception) {
            }
        }
    }

    private fun removeButton() {
        fadeHandler.removeCallbacksAndMessages(null)
        button?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        button = null
        buttonLp = null
    }

    private fun clampButton() {
        val v = button ?: return
        val lp = buttonLp ?: return
        val (sw, sh) = screenSize()
        lp.x = lp.x.coerceIn(0, max(0, sw - lp.width))
        lp.y = lp.y.coerceIn(0, max(0, sh - lp.height))
        snapToEdge(lp, sw, sh)
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    /** الزر بيلزق في أقرب حافة (يمين / شمال / فوق / تحت). */
    private fun snapToEdge(lp: WindowManager.LayoutParams, sw: Int, sh: Int) {
        val dl = lp.x
        val dr = sw - (lp.x + lp.width)
        val dt = lp.y
        val db = sh - (lp.y + lp.height)
        val m = min(min(dl, dr), min(dt, db))
        when (m) {
            dl -> lp.x = 0
            dr -> lp.x = sw - lp.width
            dt -> lp.y = 0
            else -> lp.y = sh - lp.height
        }
    }

    // ───────────── تنفيذ الإجراءات ─────────────

    private fun trigger(name: String) {
        if (playing) {
            stopPlaying()
            toast("اتوقّف التنفيذ")
            return
        }
        val g = armedGesture
        if (g != null) {
            // كورة ثابتة ظاهرة:
            //  ضغطة واحدة على الأيقونة = إخفاء الكورة
            //  ضغطتين = الهدف الرئيسي للكورة
            //  ضغطة مطولة = تشغيل الإيماءة (الخط اللي سجّلته) على مكان الكورة
            if (name == "single") {
                closeArmed()
                return
            }
            if (name == "double") {
                val t = g.ballActions["main"] ?: "none"
                if (t != "none") {
                    if (t == "self") fireArmed() else perform(t)
                    return
                }
            }
            if (name == "long") {
                fireArmed()
                return
            }
        }
        perform(Store.getAction(this, name))
    }

    /** إجراء جاي من الزر نفسه (ضغطة/ضغطتين/مطوّلة). */
    private fun perform(id: String) {
        when {
            id == "none" -> {}
            id == "menu" -> showMenu("top", true)
            id == "device" || id == "more" || id == "rotate" || id == "custom" || id == "gestures" -> showMenu(id, true)
            id.startsWith("g:") -> runSavedGesture(id.substring(2))
            id.startsWith("cmd:") -> runScript(id.substring(4))
            else -> exec(id)
        }
    }

    /**
     * إيماءة مربوطة بضغطة / ضغطتين / ضغطة مطوّلة على الزر: بتتنفّذ في مكان الكورة اللي ثبّتّها (من غير ما تفتح القايمة).
     * لو لسه ما حدّدتش مكان، بتظهر الكورة عشان تحطها.
     */
    private fun runSavedGesture(gid: String) {
        val g = Store.loadGestures(this).firstOrNull { it.id == gid }
        if (g == null) {
            toast("الإيماءة دي اتمسحت")
            return
        }
        if (!g.armed) {
            startGesture(g)
            return
        }
        if (armedGesture?.id == g.id) {
            fireArmed()
            return
        }
        val pin = Store.getPin(this, g.id)
        if (pin == null) {
            armGesture(g)
            return
        }
        runGesture(g, pin.first, pin.second, true)
    }

    private fun exec(id: String) {
        when {
            id == "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            id == "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            id == "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            id == "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            id == "control" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            id == "restart" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            id == "multitask" -> performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            id == "lock" -> {
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                else toast("قفل الشاشة بيحتاج أندرويد 9 أو أحدث")
            }
            id == "screenshot" -> {
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                else toast("لقطة الشاشة بتحتاج أندرويد 9 أو أحدث")
            }
            id == "vol_up" -> audio(AudioManager.ADJUST_RAISE)
            id == "vol_down" -> audio(AudioManager.ADJUST_LOWER)
            id == "mute" -> audio(AudioManager.ADJUST_TOGGLE_MUTE)
            id == "siri" -> voiceAssistant()
            id.startsWith("cmd:") -> runScript(id.substring(4))
            id.startsWith("scroll_") -> scrollAction(id.substring(7))
            id == "camera" -> openCamera()
            id == "move_menu" -> moveMenuButton()
            id == "access_shortcut" -> openAccessibilitySettings()
            id.startsWith("rot_") -> setRotation(id.substring(4).toIntOrNull() ?: 0)
            id == "lock_rotation" -> toggleRotationLock()
            id.startsWith("p:") || id.startsWith("swipe:") -> {
                val (sw, sh) = screenSize()
                val g = Presets.build(id, sw, sh)
                if (g != null) showPlacer(g)
            }
            id.startsWith("g:") -> {
                val g = Store.loadGestures(this).firstOrNull { it.id == id.substring(2) }
                if (g != null) startGesture(g) else toast("الإيماءة دي اتمسحت")
            }
        }
    }

    private fun scrollAction(kind: String) {
        val (sw, sh) = screenSize()
        val cx = sw / 2f
        val cy = sh / 2f
        val dy = sh * 0.28f
        val dx = sw * 0.28f
        var x1 = cx
        var y1 = cy
        var x2 = cx
        var y2 = cy
        var rep = 1
        var delay = 0L
        var dur = 320L
        when (kind) {
            "up" -> { y1 = cy + dy; y2 = cy - dy }
            "down" -> { y1 = cy - dy; y2 = cy + dy }
            "left" -> { x1 = cx + dx; x2 = cx - dx }
            "right" -> { x1 = cx - dx; x2 = cx + dx }
            "top" -> { y1 = cy - dy; y2 = cy + dy; rep = 6; delay = 60L; dur = 180L }
            "bottom" -> { y1 = cy + dy; y2 = cy - dy; rep = 6; delay = 60L; dur = 180L }
            "h" -> { x1 = cx + dx; x2 = cx - dx; rep = 0; delay = 150L }
            "v" -> { y1 = cy + dy; y2 = cy - dy; rep = 0; delay = 150L }
            else -> return
        }
        val g = Gesture(
            "scroll", "scroll",
            listOf(Stroke(0L, listOf(Pt(x1, y1, 0L), Pt(x2, y2, dur)))),
            sw, sh, repeat = rep, repeatDelay = delay
        )
        runGesture(g, 0f, 0f, true)
    }

    private fun openCamera() {
        try {
            val i = Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
            toast("مفيش تطبيق كاميرا")
        }
    }

    private fun openAccessibilitySettings() {
        try {
            val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
        }
    }

    /** "نقل القائمة": بيقلب الزر للحافة التانية ومكان تاني عشان ما يغطيش اللي تحته. */
    private fun moveMenuButton() {
        val v = button ?: return
        val lp = buttonLp ?: return
        val (sw, sh) = screenSize()
        lp.x = if (lp.x + lp.width / 2 < sw / 2) sw - lp.width else 0
        lp.y = (sh - lp.y - lp.height).coerceIn(0, max(0, sh - lp.height))
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
        Store.setPos(this, lp.x, lp.y)
        wakeButton()
    }

    private fun audio(dir: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustVolume(dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun voiceAssistant() {
        try {
            val i = Intent(Intent.ACTION_VOICE_COMMAND)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: ActivityNotFoundException) {
            try {
                val i = Intent(Intent.ACTION_ASSIST)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (_: Exception) {
                toast("مفيش مساعد صوتي متسجّل على الجهاز")
            }
        }
    }

    private fun needWriteSettings(): Boolean {
        if (Settings.System.canWrite(this)) return false
        toast("اسمح للتطبيق بتعديل إعدادات النظام الأول")
        try {
            val i = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
        }
        return true
    }

    private fun setRotation(r: Int) {
        if (needWriteSettings()) return
        try {
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            Settings.System.putInt(contentResolver, Settings.System.USER_ROTATION, r)
        } catch (_: Exception) {
            toast("ما قدرتش أغيّر اتجاه الشاشة")
        }
    }

    private fun toggleRotationLock() {
        if (needWriteSettings()) return
        try {
            val cur = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (cur == 1) 0 else 1)
            toast(if (cur == 1) "التدوير مقفول" else "التدوير شغّال")
        } catch (_: Exception) {
        }
    }

    private fun startGesture(g: Gesture) {
        when {
            g.armed -> armGesture(g)
            g.placeMode -> showPlacer(g)
            else -> runGesture(g, 0f, 0f)
        }
    }

    // ───────────── القائمة (زي قائمة AssistiveTouch) ─────────────

    private fun pageItems(page: String): List<MI> {
        fun mi(id: String) = MI(id, Actions.label(this, id), id)
        return when {
            page == "top" -> Store.topMenu(this).filter { it != "none" }.map { mi(it) }
            page == "device" -> listOf("lock", "rotate", "vol_up", "vol_down", "mute", "more").map { mi(it) }
            page == "more" -> listOf("screenshot", "recents", "restart", "multitask", "gestures", "lock_rotation", "back").map { mi(it) }
            page == "rotate" -> listOf("rot_0", "rot_1", "rot_3", "rot_2", "lock_rotation").map { mi(it) }
            page == "gestures" -> (1..5).map { mi("fingers:$it") }
            page.startsWith("fingers:") -> {
                val n = page.substring(8)
                listOf("up", "down", "left", "right").map { mi("swipe:$n:$it") }
            }
            page == "custom" -> {
                val l = ArrayList<MI>()
                for (g in Store.loadGestures(this)) l.add(mi("g:${g.id}"))
                for (id in listOf("p:pinch", "p:pinch_out", "p:pinch_rotate", "p:double_tap", "p:long_press")) l.add(mi(id))
                l.add(mi("newgesture"))
                l
            }
            else -> emptyList()
        }
    }

    private fun showMenu(page: String, reset: Boolean = false) {
        val first = menu == null
        if (reset) pageStack.clear()
        if (pageStack.lastOrNull() != page) pageStack.add(page)
        renderMenu(first)
    }

    private fun menuBack() {
        if (pageStack.isNotEmpty()) pageStack.removeAt(pageStack.size - 1)
        if (pageStack.isEmpty()) closeMenu() else renderMenu(false)
    }

    private fun onMenuItem(id: String) {
        when {
            id == "device" || id == "more" || id == "rotate" || id == "custom" ||
                id == "gestures" || id.startsWith("fingers:") -> showMenu(id)
            id == "newgesture" -> closeThen { startRecording() }
            else -> closeThen { exec(id) }
        }
    }

    private fun closeThen(action: () -> Unit) {
        closeMenu()
        handler.postDelayed({ action() }, 280)
    }

    /** ترتيب الأيقونات في شبكة 3×3 (المركز = رقم 4). */
    private fun slotsFor(count: Int, hasBack: Boolean): IntArray {
        if (hasBack) return intArrayOf(0, 1, 2, 3, 5, 6, 7, 8).copyOf(min(count, 8))
        return when (count) {
            1 -> intArrayOf(4)
            2 -> intArrayOf(3, 5)
            3 -> intArrayOf(0, 2, 7)
            4 -> intArrayOf(1, 3, 5, 7)
            5 -> intArrayOf(0, 2, 4, 6, 8)
            6 -> intArrayOf(0, 2, 3, 5, 6, 8)
            7 -> intArrayOf(0, 1, 2, 3, 5, 6, 7)
            else -> intArrayOf(0, 1, 2, 3, 5, 6, 7, 8)
        }
    }

    private fun makeCell(icon: String, label: String, onClick: () -> Unit): View {
        val cell = dp(80)
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.layoutParams = LinearLayout.LayoutParams(cell, cell)
        c.addView(IconView(this, icon), LinearLayout.LayoutParams(dp(40), dp(40)))
        if (label.isNotEmpty()) {
            val t = TextView(this)
            t.text = label
            t.textSize = 10.5f
            t.setTextColor(Color.WHITE)
            t.gravity = Gravity.CENTER
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            t.setPadding(dp(2), dp(2), dp(2), 0)
            c.addView(t, LinearLayout.LayoutParams(cell, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        c.setOnClickListener { onClick() }
        return c
    }

    private fun ringCell(m: MI?): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.addView(IconView(this, if (m == null) "chev" else m.icon), LinearLayout.LayoutParams(dp(38), dp(38)))
        if (m != null && m.label.isNotEmpty()) {
            val t = TextView(this)
            t.text = m.label
            t.textSize = 11f
            t.setTextColor(Color.WHITE)
            t.gravity = Gravity.CENTER
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            t.setPadding(0, dp(2), 0, 0)
            c.addView(t, LinearLayout.LayoutParams(dp(82), ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        c.setOnClickListener {
            if (m == null) menuBack() else onMenuItem(m.action)
        }
        return c
    }

    private fun renderMenu(animate: Boolean) {
        closeMenuView()
        val page = pageStack.lastOrNull() ?: return
        val items = pageItems(page)
        val hasBack = page != "top"
        val (sw, sh) = screenSize()

        val panel: ViewGroup
        val panelLp: FrameLayout.LayoutParams
        if (items.size <= 8) {
            val size = dp(270)
            val fp = FrameLayout(this)
            fp.background = rounded("#EE2B2B2D", 34)
            fp.isClickable = true
            val half = size / 2f
            val n = if (hasBack) max(items.size, 2) else items.size
            val offs = MenuGeometry.offsets(n, dp(88).toFloat(), dp(84).toFloat())
            val cw = dp(82)
            val ch = dp(74)
            for (i in items.indices) {
                val cell = ringCell(items[i])
                val lp = FrameLayout.LayoutParams(cw, ch)
                lp.gravity = Gravity.TOP or Gravity.START
                lp.leftMargin = (half + offs[i].x - cw / 2f).toInt()
                lp.topMargin = (half + offs[i].y - ch / 2f).toInt()
                fp.addView(cell, lp)
            }
            if (hasBack) {
                val lp = FrameLayout.LayoutParams(dp(56), dp(56))
                lp.gravity = Gravity.CENTER
                fp.addView(ringCell(null), lp)
            }
            panel = fp
            panelLp = FrameLayout.LayoutParams(size, size, Gravity.CENTER)
        } else {
            val cell = dp(80)
            val all = ArrayList<View>()
            if (hasBack) all.add(makeCell("chev", "") { menuBack() })
            for (m in items) all.add(makeCell(m.icon, m.label) { onMenuItem(m.action) })
            val grid = LinearLayout(this)
            grid.orientation = LinearLayout.VERTICAL
            var i = 0
            while (i < all.size) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for (k in i until min(i + 3, all.size)) row.addView(all[k])
                grid.addView(row)
                i += 3
            }
            val rows = (all.size + 2) / 3
            val scroll = ScrollView(this)
            scroll.addView(grid)
            val lp2 = LinearLayout(this)
            lp2.orientation = LinearLayout.VERTICAL
            lp2.background = rounded("#EE2B2B2D", 26)
            lp2.setPadding(dp(8), dp(8), dp(8), dp(8))
            lp2.isClickable = true
            lp2.addView(
                scroll,
                LinearLayout.LayoutParams(cell * 3, min(cell * rows, (sh * 0.75f).toInt()))
            )
            panel = lp2
            panelLp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        }

        val root = FrameLayout(this)
        root.setOnClickListener { closeMenu() }
        root.addView(panel, panelLp)

        try {
            wm.addView(root, fullScreenParams())
            menu = root
            button?.visibility = View.INVISIBLE
        } catch (_: Exception) {
            return
        }

        if (animate) {
            panel.alpha = 0f
            panel.scaleX = 0.3f
            panel.scaleY = 0.3f
            panel.post {
                val bl = buttonLp
                val bx = if (bl != null) bl.x + bl.width / 2f else sw / 2f
                val by = if (bl != null) bl.y + bl.height / 2f else sh / 2f
                panel.pivotX = panel.width / 2f + (bx - sw / 2f)
                panel.pivotY = panel.height / 2f + (by - sh / 2f)
                panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
            }
        }
    }

    private fun closeMenuView() {
        menu?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        menu = null
    }

    private fun closeMenu() {
        closeMenuView()
        pageStack.clear()
        button?.visibility = View.VISIBLE
        wakeButton()
    }

    // ───────────── تسجيل إيماءة جديدة ─────────────

    fun startRecording() {
        closeOverlays()
        val (sw, sh) = screenSize()
        val v = RecorderView(
            this, sw, sh,
            onSave = { g ->
                handler.post {
                    closeRecorder()
                    pending = g
                    openEditor(null)
                }
            },
            onCancel = { handler.post { closeRecorder() } }
        )
        try {
            wm.addView(v, fullScreenParams())
            recorder = v
        } catch (_: Exception) {
        }
    }

    private fun closeRecorder() {
        recorder?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        recorder = null
    }

    private fun openEditor(id: String?) {
        val i = Intent(this, GestureEditActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (id != null) i.putExtra("id", id)
        startActivity(i)
    }

    // ───────────── اختيار المكان (دواير زرقا زي iOS) ─────────────

    private fun showPlacer(g: Gesture) {
        closeOverlays()
        val (sw, sh) = screenSize()
        val v = PlaceView(
            this, g, sw, sh,
            onDone = { dx, dy ->
                handler.post {
                    closePlacer()
                    handler.postDelayed({ runGesture(g, dx, dy, true) }, 120)
                }
            },
            onCancel = { handler.post { closePlacer() } }
        )
        try {
            wm.addView(v, fullScreenParams())
            placer = v
        } catch (_: Exception) {
        }
    }

    private fun closePlacer() {
        placer?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        placer = null
    }

    private fun closeOverlays() {
        closeMenu()
        closeRecorder()
        closePlacer()
        closeArmed()
    }

    // ───────────── تشغيل الإيماءة / الماكرو ─────────────

    fun stopPlaying() {
        runToken++
        playing = false
        handler.removeCallbacksAndMessages(null)
        val e = onEnd
        onEnd = null
        e?.invoke()
    }

    // ───────────── الدواير الثابتة (Armed) ─────────────

    /** نقطة الارتكاز: بداية أول لمسة في الإيماءة. الكورة بتتحط عليها. */
    private fun anchorOf(g: Gesture): PointF? {
        val st = g.strokes.minByOrNull { it.startOffset } ?: return null
        val p = st.points.firstOrNull() ?: return null
        return PointF(p.x, p.y)
    }

    /** بتظهر كور (كورة لكل لمسة مسجّلة) عشان تحرّكها. لما تسيبها بتتحوّل لكورة واحدة ثابتة. */
    private fun armGesture(g: Gesture) {
        val a = anchorOf(g) ?: return
        closeOverlays()
        val (sw, sh) = screenSize()
        val saved = Store.getPin(this, g.id)
        val tx0 = saved?.first ?: (sw / 2f - a.x)
        val ty0 = saved?.second ?: (sh / 2f - a.y)
        val starts = ArrayList<PointF>()
        for (st in g.strokes) {
            val p = st.points.firstOrNull() ?: continue
            starts.add(PointF(p.x, p.y))
        }
        // مرحلة التحريك: الكور (كورة لكل خط) بتمشي مع إصبعك لأي مكان في الشاشة. لما ترفع إصبعك بتفضل كورة واحدة ثابتة.
        val v = BallPlaceView(
            this, starts, a, tx0, ty0,
            onDone = { tx, ty ->
                handler.post {
                    closePlacer()
                    Store.setPin(this, g.id, tx, ty)
                    showBalls(g, tx, ty, false)
                }
            },
            onCancel = { handler.post { closePlacer() } }
        )
        try {
            wm.addView(v, fullScreenParams())
            placer = v
        } catch (_: Exception) {
        }
    }

    private fun showBalls(g: Gesture, tx0: Float, ty0: Float, multi: Boolean) {
        closeArmed()
        val a = anchorOf(g) ?: return
        val (sw, sh) = screenSize()
        // لو مفيش أهداف للمس: الكورة علامة بس واللمس بيعدّي للتطبيق اللي تحتها. لو فيه أهداف: بتاخد اللمس وتمرّره للتطبيق بنفسها.
        val interactive = listOf("tap", "double", "long", "up", "down", "left", "right", "swipe").any { (g.ballActions[it] ?: "none") != "none" }
        val radius = dp(Store.ballDp(this)) / 2f
        val pad = radius.toInt() + dp(30)
        val w = 2 * pad
        val h = 2 * pad
        val baseX = (a.x - pad).toInt()
        val baseY = (a.y - pad).toInt()

        var wflags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        // لو الكورة ملهاش أوامر: مبتاخدش لمس خالص (اللمس بيعدّي للتطبيق اللي تحتها)
        if (!interactive) wflags = wflags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            wflags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (baseX + tx0).toInt().coerceIn(-pad, max(-pad, sw - w + pad))
        lp.y = (baseY + ty0).toInt().coerceIn(-pad, max(-pad, sh - h + pad))

        val hasDouble = (g.ballActions["double"] ?: "none") != "none"
        val view = PinnedView(
            this, listOf(PointF(a.x - baseX, a.y - baseY)), hasDouble
        ) { key -> handler.post { onBallTrigger(g, key) } }
        // إعدادات الكورة نفسها (مستقلة عن إعدادات الهاتف)
        view.longMs = g.ballLongMs.toLong()
        view.doubleMs = g.ballDoubleMs.toLong()
        try {
            wm.addView(view, lp)
        } catch (_: Exception) {
            return
        }
        armedGesture = g
        armedView = view
        armedLp = lp
        armedBaseX = baseX
        armedBaseY = baseY
        armedMulti = false
        armedInteractive = interactive
        armedTx = tx0
        armedTy = ty0
        Store.setLastBall(this, a.x + tx0, a.y + ty0)
        applyButtonSettings()
    }

    /**
     * لمس مكان الكورة (لو ليه أهداف): بنمرّر النقرة / النقرتين / السحب / الضغطة المطولة للتطبيق اللي تحتها بإعدادات الكورة
     * (مدة النقر ومدة السحب)، وبنشغّل الهدف المكتوب للحركة دي.
     */
    private fun onBallTrigger(g: Gesture, key: String) {
        if (armedGesture?.id != g.id) return
        if (playing) {
            stopPlaying()
            return
        }
        val c = ballCenter() ?: return
        val isSwipe = key == "up" || key == "down" || key == "left" || key == "right"
        val tapMs = if (g.tapOn) g.tapMs.toLong() else 50L
        val swipeMs = if (g.swipeOn) g.swipeMs.toLong() else 100L
        val target = g.ballActions[key] ?: (if (isSwipe) g.ballActions["swipe"] else null)
        val runTarget: () -> Unit = {
            if (target != null && target != "none") {
                if (target == "self") fireArmed() else perform(target)
            }
        }
        when {
            key == "tap" -> forwardTap(c, tapMs, 1, runTarget)
            key == "double" -> forwardTap(c, tapMs, 2, runTarget)
            isSwipe -> forwardSwipe(c, swipeMs, key, runTarget)
            key == "longUp" -> forwardHold(c, (armedView as? PinnedView)?.pressMs ?: 0L)
            else -> runTarget()
        }
    }

    private fun forwardTap(c: PointF, ms: Long, n: Int, then: () -> Unit) {
        setArmedTouchable(false)
        fun tapN(i: Int) {
            injectStroke(c.x, c.y, c.x, c.y, ms) {
                if (i + 1 < n) {
                    handler.postDelayed({ tapN(i + 1) }, 60)
                } else {
                    setArmedTouchable(true)
                    handler.post { then() }
                }
            }
        }
        tapN(0)
    }

    private fun forwardSwipe(c: PointF, ms: Long, dir: String, then: () -> Unit) {
        val pv = armedView as? PinnedView
        val dist = max(pv?.swipeDist ?: 0f, dp(80).toFloat())
        val x2 = c.x + (if (dir == "left") -dist else if (dir == "right") dist else 0f)
        val y2 = c.y + (if (dir == "up") -dist else if (dir == "down") dist else 0f)
        setArmedTouchable(false)
        injectStroke(c.x, c.y, x2, y2, ms) {
            setArmedTouchable(true)
            handler.post { then() }
        }
    }

    private fun forwardHold(c: PointF, ms: Long) {
        if (ms <= 0L) return
        setArmedTouchable(false)
        injectStroke(c.x, c.y, c.x, c.y, min(ms, 5000L)) { setArmedTouchable(true) }
    }

    // ───────────── الأهداف المكتوبة (بتتنفّذ فعلاً بلمس حقيقي وإجراءات النظام) ─────────────

    /** مكان الكورة: لو ظاهرة بنستخدم مكانها، ولو مخفية بنستخدم آخر مكان اتحطت فيه. */
    private fun ballCenter(): PointF? {
        val g = armedGesture
        if (g != null) {
            val a = anchorOf(g)
            if (a != null) return PointF(a.x + armedTx, a.y + armedTy)
        }
        val last = Store.lastBall(this) ?: return null
        return PointF(last.first, last.second)
    }

    private fun injectStroke(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long, done: () -> Unit) {
        val (sw, sh) = screenSize()
        val path = Path()
        path.moveTo(x1.coerceIn(0f, sw - 1f), y1.coerceIn(0f, sh - 1f))
        if (abs(x2 - x1) + abs(y2 - y1) >= 2f) {
            path.lineTo(x2.coerceIn(0f, sw - 1f), y2.coerceIn(0f, sh - 1f))
        }
        val dur = min(max(1L, ms), GestureDescription.getMaxGestureDuration())
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0L, dur)).build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    done()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    done()
                }
            },
            null
        )
        if (!ok) done()
    }

    private fun runScript(src: String) {
        stopPlaying()
        val (sw, sh) = screenSize()
        val c = ballCenter() ?: PointF(sw / 2f, sh / 2f)
        val g = armedGesture
        val defSwipe = if (g != null && g.swipeOn) g.swipeMs.toLong() else 100L
        val defTap = if (g != null && g.tapOn) g.tapMs.toLong() else 50L
        val steps = parseScript(src, c, defTap, defSwipe)
        if (steps.isEmpty()) {
            toast("الهدف مش مفهوم: بيفهم أوامر محددة بس (tap / swipe / hold / wait / home ...) ومش بيفهم كلام عادي")
            return
        }
        setArmedTouchable(false)
        onEnd = { setArmedTouchable(true) }
        val token = ++runToken
        playing = true
        fun next(i: Int) {
            if (token != runToken) return
            if (i >= steps.size) {
                stopPlaying()
                return
            }
            steps[i].invoke { handler.post { next(i + 1) } }
        }
        next(0)
    }

    private fun parseScript(src: String, center: PointF, defTapMs: Long, defSwipeMs: Long): List<Step> {
        val steps = ArrayList<Step>()
        val aliases = mapOf(
            "home" to "home", "back" to "back", "recents" to "recents", "notifications" to "notifications",
            "control" to "control", "quick" to "control", "lock" to "lock", "screenshot" to "screenshot",
            "power" to "restart", "menu" to "menu", "camera" to "camera", "siri" to "siri",
            "volume_up" to "vol_up", "volume_down" to "vol_down", "vol_up" to "vol_up", "vol_down" to "vol_down",
            "mute" to "mute", "multitask" to "multitask"
        )
        val timesRe = Regex("^[x*](\\d+)$", RegexOption.IGNORE_CASE)
        for (raw in src.split('\n', ';')) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val toks = ArrayList(line.split(Regex("\\s+")))
            var times = 1
            if (toks.size > 1) {
                val m = timesRe.find(toks[toks.size - 1])
                if (m != null) {
                    times = (m.groupValues[1].toIntOrNull() ?: 1).coerceIn(1, 1000)
                    toks.removeAt(toks.size - 1)
                }
            }
            val cmdWords = mapOf(
                "اضغط" to "tap", "انقر" to "tap", "نقرة" to "tap",
                "اسحب" to "swipe", "سحب" to "swipe",
                "انتظر" to "wait", "استنى" to "wait",
                "افتح" to "open", "رابط" to "url", "شغل" to "run"
            )
            val cmd = cmdWords[toks[0]] ?: toks[0].lowercase()
            val dirWords = mapOf(
                "فوق" to "up", "اعلى" to "up", "لأعلى" to "up", "لفوق" to "up",
                "تحت" to "down", "اسفل" to "down", "لأسفل" to "down", "لتحت" to "down",
                "يمين" to "right", "لليمين" to "right", "شمال" to "left", "يسار" to "left", "لليسار" to "left", "لشمال" to "left"
            )
            val args = toks.drop(1).map { dirWords[it] ?: it }
            val nums = args.mapNotNull { it.toFloatOrNull() }
            var st: Step? = null
            when (cmd) {
                "tap", "click", "hold", "long" -> {
                    val defMs = if (cmd == "hold" || cmd == "long") 600f else defTapMs.toFloat()
                    val x: Float
                    val y: Float
                    val ms: Long
                    if (nums.size >= 2) {
                        x = nums[0]
                        y = nums[1]
                        ms = (nums.getOrNull(2) ?: defMs).toLong()
                    } else {
                        x = center.x
                        y = center.y
                        ms = (nums.getOrNull(0) ?: defMs).toLong()
                    }
                    st = { done -> injectStroke(x, y, x, y, ms, done) }
                }
                "swipe", "drag" -> {
                    val dir = args.getOrNull(0)?.lowercase()
                    if (dir == "up" || dir == "down" || dir == "left" || dir == "right") {
                        val rest = args.drop(1).mapNotNull { it.toFloatOrNull() }
                        val dist = rest.getOrNull(0) ?: 300f
                        val ms = (rest.getOrNull(1) ?: defSwipeMs.toFloat()).toLong()
                        val x2 = center.x + (if (dir == "left") -dist else if (dir == "right") dist else 0f)
                        val y2 = center.y + (if (dir == "up") -dist else if (dir == "down") dist else 0f)
                        st = { done -> injectStroke(center.x, center.y, x2, y2, ms, done) }
                    } else if (nums.size >= 4) {
                        val ms = (nums.getOrNull(4) ?: defSwipeMs.toFloat()).toLong()
                        val a = nums[0]
                        val b = nums[1]
                        val c2 = nums[2]
                        val d = nums[3]
                        st = { done -> injectStroke(a, b, c2, d, ms, done) }
                    }
                }
                "wait", "sleep", "delay" -> {
                    val ms = (nums.getOrNull(0) ?: 100f).toLong()
                    st = { done -> handler.postDelayed({ done() }, ms) }
                }
                "open", "launch" -> {
                    val pkg = args.getOrNull(0)
                    if (pkg != null) st = { done -> openApp(pkg); handler.postDelayed({ done() }, 500) }
                }
                "url" -> {
                    val link = args.joinToString(" ")
                    if (link.isNotEmpty()) st = { done -> openUrl(link); handler.postDelayed({ done() }, 500) }
                }
                "run" -> {
                    val name = args.joinToString(" ")
                    if (name.isNotEmpty()) st = { done -> runByName(name); handler.postDelayed({ done() }, 200) }
                }
                else -> {
                    val id = aliases[cmd]
                    if (id != null) st = { done -> perform(id); handler.postDelayed({ done() }, 150) }
                }
            }
            val s1 = st
            if (s1 != null) {
                for (i in 0 until times) {
                    steps.add(s1)
                    if (i < times - 1) steps.add { done -> handler.postDelayed({ done() }, 30) }
                }
            }
        }
        return steps
    }

    private fun openApp(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            toast("التطبيق مش موجود: $pkg")
            return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun openUrl(link: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(link))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
            toast("الرابط مش صحيح")
        }
    }

    private fun runByName(name: String) {
        val g = Store.loadGestures(this).firstOrNull { it.name.equals(name, ignoreCase = true) }
        if (g == null) {
            toast("مفيش إيماءة اسمها $name")
            return
        }
        runSavedGesture(g.id)
    }

    private fun setArmedTouchable(touchable: Boolean) {
        val v = armedView ?: return
        val lp = armedLp ?: return
        // الكورة الواحدة بتفضل غير قابلة للمس دايماً، والكور المتعددة (وقت التحريك) بس هي اللي ممكن تتلمس
        val ok = touchable && armedInteractive
        lp.flags = if (ok) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    private fun fireArmed(after: (() -> Unit)? = null) {
        val g = armedGesture ?: return
        val offX = armedTx
        val offY = armedTy
        // نخلي الكورة "شفافة للمس" وقت التنفيذ عشان اللمسة توصل للتطبيق اللي تحتها
        setArmedTouchable(false)
        runGesture(g, offX, offY, true, after) { setArmedTouchable(true) }
    }

    private fun closeArmed() {
        armedView?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        armedView = null
        armedLp = null
        armedGesture = null
        applyButtonSettings()
    }

    private fun runGesture(g: Gesture, offX: Float, offY: Float, keepScale: Boolean = false, after: (() -> Unit)? = null, end: (() -> Unit)? = null) {
        stopPlaying()
        val (sw, sh) = screenSize()
        if (!keepScale && (g.screenW > g.screenH) != (sw > sh)) {
            toast("اتجاه الشاشة مختلف عن وقت التسجيل (طولي / عرضي)")
            end?.invoke()
            return
        }
        val sx = if (keepScale) 1f else sw.toFloat() / g.screenW
        val sy = if (keepScale) 1f else sh.toFloat() / g.screenH
        val chain = if (g.keepPauses) buildChain(g, sw, sh, sx, sy, offX, offY) else null
        val chunks = if (chain == null) buildChunks(g, sw, sh, sx, sy, offX, offY) else emptyList()
        if (chain == null && chunks.isEmpty()) {
            end?.invoke()
            return
        }
        onEnd = end

        val token = ++runToken
        playing = true
        var count = 0

        fun again() {
            if (token != runToken) return
            val finished: () -> Unit = {
                count++
                if (g.repeat > 0 && count >= g.repeat) {
                    stopPlaying()
                    after?.invoke()
                } else {
                    handler.postDelayed({ again() }, g.repeatDelay)
                }
            }
            if (chain != null) runChain(chain, 0, null, token, finished)
            else runChunks(chunks, 0, 0L, token, finished)
        }
        again()
    }

    /**
     * إصبع واحد فيه "وقفة" (مثلاً: اضغط واستنى ثم اسحب): نقسمها لمراحل ونكمّلها كإصبع واحد نازل طول الوقت،
     * عشان التوقيت يطلع زي التسجيل بالظبط. غير كده بنرجع null ونستخدم الطريقة العادية.
     */
    private fun buildChain(g: Gesture, sw: Int, sh: Int, sx: Float, sy: Float, offX: Float, offY: Float): List<Seg>? {
        if (g.strokes.size != 1) return null
        val s = g.strokes[0]
        val n = s.points.size
        if (n < 3) return null
        val speed = if (g.speed < 0.1f) 1f else g.speed
        val xs = FloatArray(n) { (s.points[it].x * sx + offX).coerceIn(0f, sw - 1f) }
        val ys = FloatArray(n) { (s.points[it].y * sy + offY).coerceIn(0f, sh - 1f) }
        val ts = LongArray(n) { s.points[it].t }
        val maxDur = GestureDescription.getMaxGestureDuration()

        val segs = ArrayList<Seg>()
        var cur = Path()
        cur.moveTo(xs[0], ys[0])
        var curStart = ts[0]
        var hasHold = false

        for (k in 0 until n - 1) {
            val dt = ts[k + 1] - ts[k]
            if (dt >= 150L) {
                hasHold = true
                if (ts[k] - curStart > 0L) {
                    cur.lineTo(xs[k], ys[k])
                    segs.add(Seg(cur, max(1L, ((ts[k] - curStart) / speed).toLong())))
                }
                val hold = Path()
                hold.moveTo(xs[k], ys[k])
                segs.add(Seg(hold, max(1L, (dt / speed).toLong())))
                cur = Path()
                cur.moveTo(xs[k], ys[k])
                cur.lineTo(xs[k + 1], ys[k + 1])
                curStart = ts[k + 1]
            } else {
                cur.lineTo(xs[k + 1], ys[k + 1])
            }
        }
        val tail = ts[n - 1] - curStart
        if (tail > 0L) segs.add(Seg(cur, max(1L, (tail / speed).toLong())))

        if (!hasHold || segs.size < 2) return null
        return segs.map { Seg(it.path, min(it.dur, maxDur)) }
    }

    private fun runChain(segs: List<Seg>, idx: Int, prev: GestureDescription.StrokeDescription?, token: Int, done: () -> Unit) {
        if (token != runToken) return
        val seg = segs[idx]
        val last = idx == segs.size - 1
        val sd = if (prev == null) {
            GestureDescription.StrokeDescription(seg.path, 0L, seg.dur, !last)
        } else {
            prev.continueStroke(seg.path, 0L, seg.dur, !last)
        }
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(sd).build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (last) done() else runChain(segs, idx + 1, sd, token, done)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (token == runToken) stopPlaying()
                }
            },
            null
        )
        if (!ok) stopPlaying()
    }

    /**
     * مدة اللمسة بعد تقليص الوقفات: لو الإصبع وقف أكتر من 80ms في نص الخط (أو في الآخر قبل ما يرفعه) بنحسبها 80ms.
     * ده بيمنع إن الخط يتنفّذ كأنه ضغطة مطوّلة. اللمسة الثابتة (ضغطة/ضغطة مطوّلة) مبتتغيّرش.
     */
    private fun effectiveDuration(g: Gesture, s: Stroke): Long {
        var travel = 0f
        for (i in 1 until s.points.size) {
            travel += abs(s.points[i].x - s.points[i - 1].x) + abs(s.points[i].y - s.points[i - 1].y)
        }
        // لمسة ثابتة (نقرة): مدة النقر بتاعة الكورة
        if (travel < 8f) return if (g.tapOn) g.tapMs.toLong() else s.duration
        // خط متحرك: مدة السحب بتاعة الكورة، وبعدها سرعة اللمس
        if (g.swipeOn) return g.swipeMs.toLong()
        if (g.strokeMs > 0) return g.strokeMs.toLong()
        var total = 0L
        for (i in 1 until s.points.size) {
            total += min(max(1L, s.points[i].t - s.points[i - 1].t), 80L)
        }
        return max(total, 30L)
    }

    private fun buildChunks(g: Gesture, sw: Int, sh: Int, sx: Float, sy: Float, offX: Float, offY: Float): List<Chunk> {
        val speed = if (g.speed < 0.1f) 1f else g.speed
        val maxStrokes = GestureDescription.getMaxStrokeCount()
        val maxDur = GestureDescription.getMaxGestureDuration()

        val specs = ArrayList<Spec>()
        for (s in g.strokes.sortedBy { it.startOffset }) {
            val n = s.points.size
            if (n == 0) continue
            val xs = FloatArray(n)
            val ys = FloatArray(n)
            var travel = 0f
            for (i in 0 until n) {
                xs[i] = (s.points[i].x * sx + offX).coerceIn(0f, sw - 1f)
                ys[i] = (s.points[i].y * sy + offY).coerceIn(0f, sh - 1f)
                if (i > 0) travel += abs(xs[i] - xs[i - 1]) + abs(ys[i] - ys[i - 1])
            }
            val path = Path()
            path.moveTo(xs[0], ys[0])
            if (travel >= 2f) {
                for (i in 1 until n) path.lineTo(xs[i], ys[i])
            }
            val base = if (g.keepPauses) s.duration else effectiveDuration(g, s)
            val dur = min(max(1L, (base / speed).toLong()), maxDur)
            specs.add(Spec(if (g.simultaneous) 0L else (s.startOffset / speed).toLong(), dur, path))
        }

        val chunks = ArrayList<Chunk>()
        var i = 0
        while (i < specs.size) {
            val part = ArrayList(specs.subList(i, min(i + maxStrokes, specs.size)))
            chunks.add(Chunk(part, part.minOf { it.start }, part.maxOf { it.start + it.dur }))
            i += maxStrokes
        }
        return chunks
    }

    private fun runChunks(chunks: List<Chunk>, idx: Int, prevEnd: Long, token: Int, done: () -> Unit) {
        if (token != runToken) return
        if (idx >= chunks.size) {
            done()
            return
        }
        val c = chunks[idx]
        val wait = if (idx == 0) 0L else max(0L, c.minStart - prevEnd)
        handler.postDelayed({
            if (token != runToken) return@postDelayed
            val b = GestureDescription.Builder()
            for (s in c.specs) {
                b.addStroke(GestureDescription.StrokeDescription(s.path, s.start - c.minStart, s.dur))
            }
            val ok = dispatchGesture(
                b.build(),
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        runChunks(chunks, idx + 1, c.endTime, token, done)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (token == runToken) stopPlaying()
                    }
                },
                null
            )
            if (!ok) stopPlaying()
        }, wait)
    }
}
